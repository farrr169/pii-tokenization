require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function seed() {
  console.log('🌱 Seeding database...');

  // Roles
  const roles = await Promise.all([
    prisma.role.upsert({ where: { role_name: 'Admin' }, update: {}, create: { role_name: 'Admin', description: 'Full system access' } }),
    prisma.role.upsert({ where: { role_name: 'Operator' }, update: {}, create: { role_name: 'Operator', description: 'Can perform tokenization operations' } }),
    prisma.role.upsert({ where: { role_name: 'Auditor' }, update: {}, create: { role_name: 'Auditor', description: 'Read-only access to audit logs' } }),
    prisma.role.upsert({ where: { role_name: 'Viewer' }, update: {}, create: { role_name: 'Viewer', description: 'Read-only dashboard access' } }),
  ]);
  console.log('✅ Roles seeded:', roles.map(r => r.role_name).join(', '));

  // Default Admin User
  const adminRole = roles.find(r => r.role_name === 'Admin');
  const adminHash = await bcrypt.hash('Admin@12345', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@system.id' },
    update: {},
    create: {
      full_name: 'System Administrator',
      email: 'admin@system.id',
      password_hash: adminHash,
      role_id: adminRole.id,
      status: 'active'
    }
  });
  console.log('✅ Admin user seeded:', admin.email);

  // PII Types
  const piiTypes = [
    { name: 'NIK', category: 'Identitas', validation_regex: '^\\d{16}$', min_length: 16, max_length: 16, example_value: '3276011203990001' },
    { name: 'NPWP', category: 'Pajak', validation_regex: '^\\d{15}$', min_length: 15, max_length: 15, example_value: '012345678901234' },
    { name: 'Nomor Rekening', category: 'Finansial', validation_regex: '^\\d{10,16}$', min_length: 10, max_length: 16, example_value: '1234567890' },
    { name: 'Kartu Kredit', category: 'Finansial', validation_regex: '^\\d{13,19}$', min_length: 13, max_length: 19, example_value: '4111111111111111' },
    { name: 'Nomor Telepon', category: 'Kontak', validation_regex: '^(08|\\+62)\\d{8,11}$', min_length: 10, max_length: 15, example_value: '081234567890' },
    { name: 'Email', category: 'Kontak', validation_regex: '^[^@]+@[^@]+\\.[^@]+$', min_length: 5, max_length: 150, example_value: 'user@example.com' },
    { name: 'Passport', category: 'Identitas', validation_regex: '^[A-Z]{1,2}\\d{6,7}$', min_length: 7, max_length: 9, example_value: 'A1234567' },
    { name: 'Nama Lengkap', category: 'Identitas', min_length: 2, max_length: 100, example_value: 'John Doe' },
  ];

  for (const pii of piiTypes) {
    await prisma.piiType.upsert({
      where: { id: (await prisma.piiType.findFirst({ where: { name: pii.name } }))?.id || '00000000-0000-0000-0000-000000000000' },
      update: {},
      create: pii
    });
  }
  console.log('✅ PII Types seeded');

  // Tokenization Methods
  const methods = [
    { method_name: 'Full FPE FF1', description: 'Format-Preserving Encryption menggunakan FF1 algorithm', supports_tweak: true, is_deterministic: true },
    { method_name: 'Full FPE FF3', description: 'Format-Preserving Encryption menggunakan FF3-1 algorithm', supports_tweak: true, is_deterministic: true },
    { method_name: 'Partial FPE', description: 'FPE dengan preserve prefix/suffix', supports_prefix: true, supports_suffix: true, supports_tweak: true, is_deterministic: true },
    { method_name: 'Masking', description: 'Mengganti karakter dengan mask (*)', supports_prefix: true, supports_suffix: true, is_deterministic: false },
    { method_name: 'Hashing SHA-256', description: 'One-way hash menggunakan SHA-256', is_deterministic: true },
    { method_name: 'Deterministic Token', description: 'Token deterministik berbasis lookup', is_deterministic: true },
    { method_name: 'Random Token', description: 'Token acak non-deterministik', is_deterministic: false },
  ];

  for (const m of methods) {
    await prisma.tokenizationMethod.upsert({
      where: { id: (await prisma.tokenizationMethod.findFirst({ where: { method_name: m.method_name } }))?.id || '00000000-0000-0000-0000-000000000000' },
      update: {},
      create: m
    });
  }
  console.log('✅ Tokenization Methods seeded');

  // Tweaks
  const tweaks = [
    { tweak_name: 'Static Tweak Default', tweak_type: 'STATIC', tweak_value: 'TOKENSYSTEM2024', tweak_length: 15, description: 'Tweak statis default' },
    { tweak_name: 'Dynamic Timestamp', tweak_type: 'DYNAMIC', tweak_length: 8, description: 'Tweak berdasarkan timestamp' },
    { tweak_name: 'Randomized 8-byte', tweak_type: 'RANDOMIZED', tweak_length: 8, description: 'Tweak acak 8 byte' },
    { tweak_name: 'User-Based Tweak', tweak_type: 'USER_BASED', tweak_length: 16, description: 'Tweak berbasis user ID' },
  ];

  for (const t of tweaks) {
    await prisma.tweak.upsert({
      where: { id: (await prisma.tweak.findFirst({ where: { tweak_name: t.tweak_name } }))?.id || '00000000-0000-0000-0000-000000000000' },
      update: {},
      create: t
    });
  }
  console.log('✅ Tweaks seeded');

  // System Settings
  const settings = [
    { setting_key: 'fpe_key', setting_value: 'AES256DEFAULTKEY1234567890ABCDEF', description: 'AES Key untuk FPE (ganti di production)' },
    { setting_key: 'max_batch_size', setting_value: '1000', description: 'Max record per batch job' },
    { setting_key: 'token_expiry_days', setting_value: '365', description: 'Masa berlaku token dalam hari' },
    { setting_key: 'audit_retention_days', setting_value: '730', description: 'Retensi audit log dalam hari' },
    { setting_key: 'app_version', setting_value: '1.0.0', description: 'Versi aplikasi' },
  ];

  for (const s of settings) {
    await prisma.systemSetting.upsert({ where: { setting_key: s.setting_key }, update: {}, create: s });
  }
  console.log('✅ System Settings seeded');

  console.log('\n🎉 Seeding selesai!');
  console.log('📧 Login: admin@system.id');
  console.log('🔑 Password: Admin@12345');
}

seed()
  .catch(e => { console.error('❌ Seed error:', e); process.exit(1); })
  .finally(() => prisma.$disconnect());
