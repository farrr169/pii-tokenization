import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './store/auth.store'

// Pages
import Login from './pages/auth/Login'
import Dashboard from './pages/dashboard/Dashboard'
import Settings from './pages/settings/Settings'
import AccessManagement from './pages/access/AccessManagement'
import TweakPage from './pages/tweaks/TweakPage'

// Lazy-ish inline pages for remaining routes
import { DashboardLayout } from './components/layout/DashboardLayout'
import { DataTable, StatusBadge, Badge, SearchInput, Button, Modal, FormField } from './components/ui'
import { useState } from 'react'
import { Plus, RefreshCw } from 'lucide-react'

// ── Protected Route ────────────────────────────────────────────
function Protected({ children }) {
  const { token } = useAuthStore()
  if (!token) return <Navigate to="/login" replace />
  return children
}

// ── PII Types Page ─────────────────────────────────────────────
const MOCK_PII = [
  { id:'1', name:'NIK', category:'Identitas', min_length:16, max_length:16, example_value:'3276011203990001', is_active:true },
  { id:'2', name:'NPWP', category:'Pajak', min_length:15, max_length:15, example_value:'012345678901234', is_active:true },
  { id:'3', name:'Nomor Rekening', category:'Finansial', min_length:10, max_length:16, example_value:'1234567890', is_active:true },
  { id:'4', name:'Kartu Kredit', category:'Finansial', min_length:13, max_length:19, example_value:'4111111111111111', is_active:true },
  { id:'5', name:'Nomor Telepon', category:'Kontak', min_length:10, max_length:15, example_value:'081234567890', is_active:true },
  { id:'6', name:'Email', category:'Kontak', min_length:5, max_length:150, example_value:'user@example.com', is_active:true },
  { id:'7', name:'Passport', category:'Identitas', min_length:7, max_length:9, example_value:'A1234567', is_active:true },
  { id:'8', name:'Nama Lengkap', category:'Identitas', min_length:2, max_length:100, example_value:'John Doe', is_active:false },
]
const CAT_COLORS = { Identitas:'blue', Finansial:'green', Pajak:'amber', Kontak:'gray' }

function PIITypesPage() {
  const [list, setList] = useState(MOCK_PII)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name:'', category:'Identitas', min_length:'', max_length:'', example_value:'' })

  const filtered = list.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.category.toLowerCase().includes(search.toLowerCase()))

  const cols = [
    { key:'name', label:'Nama', render: v => <span className="font-medium">{v}</span> },
    { key:'category', label:'Kategori', render: (v) => <Badge text={v} variant={CAT_COLORS[v]||'gray'} /> },
    { key:'min_length', label:'Min', render: (v,r) => `${v}–${r.max_length}` },
    { key:'example_value', label:'Contoh', render: v => <code className="text-xs text-gray-500 font-mono">{v}</code> },
    { key:'is_active', label:'Status', render: (v,r) => (
      <button onClick={() => setList(l => l.map(p => p.id===r.id ? {...p, is_active:!p.is_active} : p))}
        className={`text-xs px-2.5 py-1 rounded-full border ${v ? 'border-green-200 text-green-700 bg-green-50' : 'border-gray-200 text-gray-500'}`}>
        {v ? 'Aktif' : 'Nonaktif'}
      </button>
    )},
  ]

  return (
    <DashboardLayout title="Master PII Types" actions={<><SearchInput value={search} onChange={setSearch} placeholder="Cari PII type..." /><Button label="Tambah" variant="primary" icon={Plus} onClick={() => setShowModal(true)} /></>}>
      <DataTable columns={cols} data={filtered} />
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Tambah PII Type"
        footer={<><Button label="Batal" onClick={() => setShowModal(false)} /><Button label="Simpan" variant="primary" onClick={() => { setList(p => [...p, {...form, id:Date.now().toString(), is_active:true}]); setShowModal(false) }} /></>}>
        <FormField label="Nama" required><input className="input-field" value={form.name} onChange={e => setForm(f => ({...f, name:e.target.value}))} /></FormField>
        <FormField label="Kategori"><select className="select-field" value={form.category} onChange={e => setForm(f => ({...f, category:e.target.value}))}>{['Identitas','Finansial','Pajak','Kontak'].map(c => <option key={c}>{c}</option>)}</select></FormField>
        <div className="grid grid-cols-2 gap-3">
          <FormField label="Min Panjang"><input type="number" className="input-field" value={form.min_length} onChange={e => setForm(f => ({...f, min_length:e.target.value}))} /></FormField>
          <FormField label="Max Panjang"><input type="number" className="input-field" value={form.max_length} onChange={e => setForm(f => ({...f, max_length:e.target.value}))} /></FormField>
        </div>
        <FormField label="Contoh Nilai"><input className="input-field font-mono" value={form.example_value} onChange={e => setForm(f => ({...f, example_value:e.target.value}))} /></FormField>
      </Modal>
    </DashboardLayout>
  )
}

// ── Methods Page ───────────────────────────────────────────────
const MOCK_METHODS_DATA = [
  { id:'1', method_name:'Full FPE FF1', description:'Format-Preserving Encryption FF1', supports_tweak:true, is_deterministic:true, is_active:true },
  { id:'2', method_name:'Full FPE FF3', description:'Format-Preserving Encryption FF3-1', supports_tweak:true, is_deterministic:true, is_active:true },
  { id:'3', method_name:'Partial FPE', description:'FPE dengan preserve prefix/suffix', supports_prefix:true, supports_suffix:true, supports_tweak:true, is_deterministic:true, is_active:true },
  { id:'4', method_name:'Masking', description:'Mengganti karakter dengan mask (*)', supports_prefix:true, supports_suffix:true, is_deterministic:false, is_active:true },
  { id:'5', method_name:'Hashing SHA-256', description:'One-way hash SHA-256', is_deterministic:true, is_active:true },
  { id:'6', method_name:'Deterministic Token', description:'Token deterministik', is_deterministic:true, is_active:true },
  { id:'7', method_name:'Random Token', description:'Token acak non-deterministik', is_deterministic:false, is_active:true },
]

function MethodsPage() {
  return (
    <DashboardLayout title="Tokenization Methods">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {MOCK_METHODS_DATA.map(m => (
          <div key={m.id} className="card">
            <div className="font-semibold text-gray-800 mb-1">{m.method_name}</div>
            <p className="text-sm text-gray-500 mb-3">{m.description}</p>
            <div className="flex flex-wrap gap-1.5">
              {m.supports_tweak && <Badge text="Tweak Support" variant="amber" />}
              {m.supports_prefix && <Badge text="Prefix" variant="green" />}
              {m.supports_suffix && <Badge text="Suffix" variant="green" />}
              <Badge text={m.is_deterministic ? 'Deterministik' : 'Random'} variant={m.is_deterministic ? 'blue' : 'gray'} />
            </div>
          </div>
        ))}
      </div>
    </DashboardLayout>
  )
}

// ── Rules Page ─────────────────────────────────────────────────
const MOCK_RULES_DATA = [
  { id:'1', rule_name:'NIK Full FPE', pii_type:{name:'NIK'}, method:{method_name:'Full FPE FF1'}, tweak:{tweak_name:'Static Tweak Default'}, preserve_prefix:6, preserve_suffix:0, maintain_length:true, is_active:true },
  { id:'2', rule_name:'Rekening Masking', pii_type:{name:'Nomor Rekening'}, method:{method_name:'Masking'}, tweak:null, preserve_prefix:4, preserve_suffix:2, maintain_length:true, is_active:true },
  { id:'3', rule_name:'Kartu Kredit PCI', pii_type:{name:'Kartu Kredit'}, method:{method_name:'Partial FPE'}, tweak:{tweak_name:'Randomized 8-byte'}, preserve_prefix:6, preserve_suffix:4, maintain_length:true, is_active:true },
  { id:'4', rule_name:'NPWP FPE', pii_type:{name:'NPWP'}, method:{method_name:'Full FPE FF3'}, tweak:{tweak_name:'Dynamic Timestamp'}, preserve_prefix:0, preserve_suffix:0, maintain_length:true, is_active:false },
]

function RulesPage() {
  const [search, setSearch] = useState('')
  const filtered = MOCK_RULES_DATA.filter(r => r.rule_name.toLowerCase().includes(search.toLowerCase()))
  return (
    <DashboardLayout title="Tokenization Rules" actions={<><SearchInput value={search} onChange={setSearch} placeholder="Cari rule..." /><Button label="Buat Rule" variant="primary" icon={Plus} /></>}>
      <div className="grid grid-cols-1 gap-3">
        {filtered.map(r => (
          <div key={r.id} className={`card ${!r.is_active ? 'opacity-60' : ''}`}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <span className="font-semibold text-gray-800">{r.rule_name}</span>
                {!r.is_active && <span className="ml-2 text-xs text-gray-400">(nonaktif)</span>}
              </div>
              <StatusBadge status={r.is_active ? 'active' : 'inactive'} />
            </div>
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge text={r.pii_type?.name} variant="blue" />
              <Badge text={r.method?.method_name} variant="green" />
              {r.tweak && <Badge text={r.tweak.tweak_name} variant="amber" />}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[['Prefix', r.preserve_prefix], ['Suffix', r.preserve_suffix], ['Pertahankan Panjang', r.maintain_length ? 'Ya' : 'Tidak'], ['Deterministik', r.method?.is_deterministic ? 'Ya' : 'Tidak']].map(([k, v]) => (
                <div key={k} className="bg-gray-50 rounded-lg px-2.5 py-2">
                  <div className="text-xs text-gray-400">{k}</div>
                  <div className="text-sm font-medium mt-0.5">{v}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </DashboardLayout>
  )
}

// ── Jobs Page ──────────────────────────────────────────────────
const MOCK_JOBS_DATA = [
  { id:'1', job_name:'Batch NIK Nasabah Q4-2024', total_data:500, success_count:498, failed_count:2, status:'completed', created_at:new Date(Date.now()-86400000).toISOString() },
  { id:'2', job_name:'Batch Kartu Kredit Desember', total_data:1000, success_count:987, failed_count:13, status:'completed', created_at:new Date(Date.now()-172800000).toISOString() },
  { id:'3', job_name:'Batch Rekening Giro', total_data:250, success_count:0, failed_count:0, status:'pending', created_at:new Date().toISOString() },
  { id:'4', job_name:'Batch NPWP Bulanan', total_data:350, success_count:200, failed_count:0, status:'running', created_at:new Date().toISOString() },
]
const fmtDate = d => new Date(d).toLocaleString('id-ID', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })
const fmtNum = n => Number(n).toLocaleString('id-ID')

function JobsPage() {
  return (
    <DashboardLayout title="Batch Jobs" actions={<Button label="Buat Job Baru" variant="primary" icon={Plus} />}>
      <div className="grid grid-cols-1 gap-3">
        {MOCK_JOBS_DATA.map(j => {
          const rate = j.total_data > 0 ? Math.round((j.success_count / j.total_data) * 100) : 0
          return (
            <div key={j.id} className="card">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="font-semibold text-gray-800">{j.job_name}</div>
                  <div className="text-xs text-gray-400 mt-0.5">{fmtDate(j.created_at)}</div>
                </div>
                <StatusBadge status={j.status} />
              </div>
              <div className="grid grid-cols-4 gap-2 mb-3">
                {[['Total', j.total_data], ['Berhasil', j.success_count], ['Gagal', j.failed_count], ['Success Rate', j.total_data > 0 ? `${rate}%` : '-']].map(([k,v]) => (
                  <div key={k} className="bg-gray-50 rounded-lg px-2.5 py-2">
                    <div className="text-xs text-gray-400">{k}</div>
                    <div className="text-sm font-semibold mt-0.5">{fmtNum(v)}</div>
                  </div>
                ))}
              </div>
              {j.total_data > 0 && (
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width:`${rate}%`, background: rate >= 95 ? '#1D9E75' : rate >= 70 ? '#BA7517' : '#A32D2D' }} />
                </div>
              )}
            </div>
          )
        })}
      </div>
    </DashboardLayout>
  )
}

// ── Audit Page ─────────────────────────────────────────────────
const MOCK_AUDIT_DATA = [
  { id:'1', user:{full_name:'Admin System'}, module_name:'tokenization', activity:'tokenize', description:'Full FPE FF1 berhasil', ip_address:'192.168.1.10', created_at:new Date().toISOString() },
  { id:'2', user:{full_name:'Operator 1'}, module_name:'auth', activity:'login', description:'Login berhasil', ip_address:'192.168.1.25', created_at:new Date(Date.now()-300000).toISOString() },
  { id:'3', user:{full_name:'Admin System'}, module_name:'tokenization_rules', activity:'create', description:'Rule NIK Full FPE dibuat', ip_address:'192.168.1.10', created_at:new Date(Date.now()-3600000).toISOString() },
  { id:'4', user:{full_name:'Auditor 1'}, module_name:'tokenization', activity:'batch', description:'Batch 100 NIK diproses', ip_address:'10.0.0.5', created_at:new Date(Date.now()-7200000).toISOString() },
  { id:'5', user:{full_name:'Operator 2'}, module_name:'pii_types', activity:'read', description:'List PII types diakses', ip_address:'192.168.1.30', created_at:new Date(Date.now()-10800000).toISOString() },
]

const MOD_COLORS = { tokenization:'blue', auth:'green', tokenization_rules:'amber', pii_types:'gray', settings:'red' }

function AuditPage() {
  const [filter, setFilter] = useState('')
  const filtered = filter ? MOCK_AUDIT_DATA.filter(a => a.module_name === filter) : MOCK_AUDIT_DATA
  const modules = [...new Set(MOCK_AUDIT_DATA.map(a => a.module_name))]

  const cols = [
    { key:'created_at', label:'Waktu', render: v => <span className="text-gray-500 whitespace-nowrap">{fmtDate(v)}</span> },
    { key:'user', label:'User', render: v => <span className="font-medium">{v?.full_name}</span> },
    { key:'module_name', label:'Modul', render: v => <Badge text={v} variant={MOD_COLORS[v]||'gray'} /> },
    { key:'activity', label:'Aktivitas' },
    { key:'description', label:'Deskripsi', render: v => <span className="text-gray-500">{v}</span> },
    { key:'ip_address', label:'IP', render: v => <code className="text-xs font-mono text-gray-400">{v}</code> },
  ]

  return (
    <DashboardLayout title="Audit Log" actions={
      <select className="select-field text-sm w-auto" value={filter} onChange={e => setFilter(e.target.value)}>
        <option value="">Semua Modul</option>
        {modules.map(m => <option key={m} value={m}>{m}</option>)}
      </select>
    }>
      <DataTable columns={cols} data={filtered} />
    </DashboardLayout>
  )
}

// ── Results Page ───────────────────────────────────────────────
const MOCK_RESULTS = [
  { id:'1', job:{job_name:'Batch NIK Q4'}, rule:{rule_name:'NIK Full FPE'}, tokenized_value:'327601A8F3X9Q2W1', processing_time_ms:12, status:'success', created_at:new Date().toISOString() },
  { id:'2', job:{job_name:'Batch Rekening'}, rule:{rule_name:'Rekening Masking'}, tokenized_value:'1234****90', processing_time_ms:5, status:'success', created_at:new Date(Date.now()-60000).toISOString() },
  { id:'3', job:{job_name:'Batch Kartu Kredit'}, rule:{rule_name:'Kartu Kredit PCI'}, tokenized_value:'411111X7Y3Z9Q2W1', processing_time_ms:15, status:'success', created_at:new Date(Date.now()-120000).toISOString() },
  { id:'4', job:{job_name:'Batch NIK Q4'}, rule:{rule_name:'NIK Full FPE'}, tokenized_value:null, processing_time_ms:3, status:'failed', created_at:new Date(Date.now()-180000).toISOString() },
]

function ResultsPage() {
  const cols = [
    { key:'job', label:'Job', render: v => <span className="text-gray-600">{v?.job_name}</span> },
    { key:'rule', label:'Rule', render: v => <span className="font-medium">{v?.rule_name}</span> },
    { key:'tokenized_value', label:'Token Hasil', render: v => v ? <code className="text-xs font-mono text-primary bg-primary-light px-1.5 py-0.5 rounded">{v}</code> : <span className="text-gray-400">—</span> },
    { key:'processing_time_ms', label:'Waktu', render: v => <span className="text-gray-500">{v}ms</span> },
    { key:'status', label:'Status', render: v => <StatusBadge status={v} /> },
    { key:'created_at', label:'Waktu', render: v => <span className="text-gray-400 text-xs">{fmtDate(v)}</span> },
  ]
  return (
    <DashboardLayout title="Hasil Tokenisasi">
      <DataTable columns={cols} data={MOCK_RESULTS} />
    </DashboardLayout>
  )
}

// ── Demo POC ──────────────────────────────────────────────────
const FPE_METHODS = ['Full FPE FF1', 'Full FPE FF3', 'Partial FPE', 'Masking', 'Hashing SHA-256', 'Random Token']
const FPE_PII = MOCK_PII.filter(p => p.is_active)

function simulateTokenize(value, method, pre, suf) {
  const charset = /^\d+$/.test(value) ? '0123456789' : '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  const prefix = value.substring(0, pre)
  const suffix = suf > 0 ? value.substring(value.length - suf) : ''
  const core = value.substring(pre, suf > 0 ? value.length - suf : undefined)
  let tok
  if (method === 'Masking') tok = core.split('').map((c,i) => (i < 2 || i >= core.length-2) ? c : '*').join('')
  else if (method === 'Hashing SHA-256') { let h=0; for (let i=0;i<core.length;i++) h=((h<<5)-h)+core.charCodeAt(i); tok = Math.abs(h).toString(16).padStart(core.length,'0').slice(0,core.length).toUpperCase() }
  else tok = core.split('').map(c => { const ci = charset.indexOf(/^\d$/.test(c) ? c : c.toUpperCase()); if (ci<0) return c; return charset[(ci + Math.floor(Math.random()*charset.length)) % charset.length] }).join('')
  return prefix + tok + suffix
}

function DemoPOC() {
  const [piiId, setPiiId] = useState('1')
  const [value, setValue] = useState('3276011203990001')
  const [method, setMethod] = useState('Full FPE FF1')
  const [pre, setPre] = useState(6)
  const [suf, setSuf] = useState(0)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [history, setHistory] = useState([])

  const selPii = FPE_PII.find(p => p.id === piiId)

  const run = () => {
    if (!value.trim()) return
    setLoading(true)
    setTimeout(() => {
      const tok = simulateTokenize(value, method, pre, suf)
      const r = { original:value, tokenized:tok, method, pii:selPii?.name, pre, suf, time:Math.floor(Math.random()*20)+5, ts: new Date().toLocaleTimeString('id-ID') }
      setResult(r)
      setHistory(h => [r, ...h.slice(0,4)])
      setLoading(false)
    }, 500)
  }

  return (
    <DashboardLayout title="Demo POC Tokenisasi">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Input panel */}
        <div className="card space-y-4">
          <h3 className="font-semibold text-gray-800">Konfigurasi</h3>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Jenis PII</label>
            <select className="select-field" value={piiId} onChange={e => { setPiiId(e.target.value); const p = FPE_PII.find(x => x.id===e.target.value); if(p) { setValue(p.example_value||''); setPre(p.name==='NIK'||p.name==='Kartu Kredit' ? 6 : 4); setSuf(p.name==='Kartu Kredit' ? 4 : 0) } }}>
              {FPE_PII.map(p => <option key={p.id} value={p.id}>{p.name} ({p.category})</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Nilai Input</label>
            <input className="input-field font-mono tracking-widest" value={value} onChange={e => setValue(e.target.value)} />
            {selPii && <p className="text-xs text-gray-400 mt-1">Panjang: {value.length} | Ekspektasi: {selPii.min_length}–{selPii.max_length}</p>}
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Metode Tokenisasi</label>
            <select className="select-field" value={method} onChange={e => setMethod(e.target.value)}>
              {FPE_METHODS.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[['Preserve Prefix', pre, setPre], ['Preserve Suffix', suf, setSuf]].map(([l, v, fn]) => (
              <div key={l}>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">{l}: <span className="text-primary font-semibold">{v}</span></label>
                <input type="range" min={0} max={Math.max(0,Math.floor(value.length/2))} value={v} onChange={e => fn(Number(e.target.value))} className="w-full" />
              </div>
            ))}
          </div>
          {/* Preview strip */}
          {value && (
            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm tracking-widest text-center">
              <span className="text-green-600">{value.substring(0, pre)}</span>
              <span className="text-gray-500">{value.substring(pre, suf > 0 ? value.length-suf : undefined)}</span>
              <span className="text-amber-600">{suf > 0 ? value.substring(value.length-suf) : ''}</span>
            </div>
          )}
          <button onClick={run} disabled={loading || !value.trim()}
            className="btn-primary w-full justify-center py-2.5">
            {loading ? <span className="flex items-center gap-2"><span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />Memproses...</span> : '🔐 Tokenisasi'}
          </button>
        </div>

        {/* Result panel */}
        <div className="space-y-4">
          {result ? (
            <div className="card border-green-200">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center"><span className="text-green-600 text-xs">✓</span></div>
                <span className="font-medium text-green-700">Tokenisasi Berhasil</span>
                <span className="ml-auto text-xs text-gray-400">{result.time}ms</span>
              </div>
              <div className="space-y-3">
                <div>
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wide">Nilai Asli</div>
                  <div className="token-display bg-gray-50 text-gray-800 text-center">{result.original}</div>
                </div>
                <div className="text-center text-gray-300 text-lg">↓</div>
                <div>
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wide">Token Hasil</div>
                  <div className="token-display bg-primary-light text-primary text-center">{result.tokenized}</div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-4">
                {[['Metode', result.method], ['Panjang Terjaga', result.original.length === result.tokenized.length ? '✓ Ya' : '✗ Tidak'], ['PII Type', result.pii]].map(([k,v]) => (
                  <div key={k} className="bg-gray-50 rounded-lg p-2 text-center">
                    <div className="text-xs text-gray-400">{k}</div>
                    <div className="text-xs font-semibold mt-0.5 truncate" title={v}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="card flex flex-col items-center justify-center py-16 text-gray-300">
              <div className="text-5xl mb-3">🔐</div>
              <p className="text-sm">Hasil tokenisasi tampil di sini</p>
            </div>
          )}

          {history.length > 0 && (
            <div className="card">
              <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Riwayat Session</h4>
              <div className="space-y-2">
                {history.map((h, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs font-mono">
                    <span className="text-gray-400 truncate flex-1">{h.original}</span>
                    <span className="text-gray-300">→</span>
                    <span className="text-primary truncate flex-1">{h.tokenized}</span>
                    <span className="text-gray-300 flex-shrink-0">{h.ts}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}

// ── App Router ─────────────────────────────────────────────────
export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Navigate to="/dashboard" replace />} />

      <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
      <Route path="/demo" element={<Protected><DemoPOC /></Protected>} />
      <Route path="/pii-types" element={<Protected><PIITypesPage /></Protected>} />
      <Route path="/methods" element={<Protected><MethodsPage /></Protected>} />
      <Route path="/tweaks" element={<Protected><TweakPage /></Protected>} />
      <Route path="/rules" element={<Protected><RulesPage /></Protected>} />
      <Route path="/jobs" element={<Protected><JobsPage /></Protected>} />
      <Route path="/results" element={<Protected><ResultsPage /></Protected>} />
      <Route path="/audit" element={<Protected><AuditPage /></Protected>} />
      <Route path="/access" element={<Protected><AccessManagement /></Protected>} />
      <Route path="/settings" element={<Protected><Settings /></Protected>} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
