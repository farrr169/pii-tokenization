import { useState } from 'react'
import { UserPlus, Shield, Users } from 'lucide-react'
import { DashboardLayout } from '../../components/layout/DashboardLayout'
import { Button, Modal, FormField, StatusBadge, Badge } from '../../components/ui'

const ROLES = ['Admin', 'Operator', 'Auditor', 'Viewer']
const ROLE_COLORS = { Admin: 'red', Operator: 'blue', Auditor: 'amber', Viewer: 'gray' }

const MOCK_USERS = [
  { id: '1', full_name: 'System Administrator', email: 'admin@system.id', role: { role_name: 'Admin' }, status: 'active', last_login: new Date().toISOString() },
  { id: '2', full_name: 'Operator Pertama', email: 'operator1@bank.id', role: { role_name: 'Operator' }, status: 'active', last_login: new Date(Date.now() - 3600000).toISOString() },
  { id: '3', full_name: 'Audit Officer', email: 'auditor1@bank.id', role: { role_name: 'Auditor' }, status: 'active', last_login: new Date(Date.now() - 7200000).toISOString() },
  { id: '4', full_name: 'Data Viewer', email: 'viewer1@bank.id', role: { role_name: 'Viewer' }, status: 'inactive', last_login: null },
]

const PERMISSIONS_MATRIX = {
  Admin:    { tokenization: ['execute', 'read'], pii_types: ['create', 'read', 'update', 'delete'], audit_logs: ['read'], settings: ['read', 'update'], users: ['create', 'read', 'update', 'delete'] },
  Operator: { tokenization: ['execute', 'read'], pii_types: ['read'], audit_logs: [], settings: [], users: [] },
  Auditor:  { tokenization: ['read'], pii_types: ['read'], audit_logs: ['read'], settings: ['read'], users: ['read'] },
  Viewer:   { tokenization: ['read'], pii_types: ['read'], audit_logs: [], settings: ['read'], users: [] },
}

const fmtDate = d => d ? new Date(d).toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'Belum pernah'

export default function AccessManagement() {
  const [users, setUsers] = useState(MOCK_USERS)
  const [showModal, setShowModal] = useState(false)
  const [activeTab, setActiveTab] = useState('users')
  const [form, setForm] = useState({ full_name: '', email: '', password: '', role: 'Operator' })

  const handleAdd = () => {
    if (!form.full_name || !form.email) return
    setUsers(prev => [...prev, {
      id: Date.now().toString(), full_name: form.full_name, email: form.email,
      role: { role_name: form.role }, status: 'active', last_login: null
    }])
    setShowModal(false)
    setForm({ full_name: '', email: '', password: '', role: 'Operator' })
  }

  const toggleStatus = (id) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, status: u.status === 'active' ? 'inactive' : 'active' } : u))
  }

  const TABS = [{ id: 'users', label: 'Pengguna', icon: Users }, { id: 'roles', label: 'Hak Akses', icon: Shield }]

  return (
    <DashboardLayout title="Manajemen Akses"
      actions={<Button label="Tambah Pengguna" variant="primary" icon={UserPlus} onClick={() => setShowModal(true)} />}>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-200 mb-6">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${activeTab === tab.id ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            <tab.icon size={15} /> {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'users' && (
        <div className="card overflow-hidden p-0">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr className="table-header">
                {['Pengguna', 'Role', 'Status', 'Login Terakhir', 'Aksi'].map(h => <th key={h}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="table-row hover:bg-gray-50/50">
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary-light flex items-center justify-center text-xs font-semibold text-primary">
                        {u.full_name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium text-gray-800">{u.full_name}</div>
                        <div className="text-xs text-gray-400">{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td><Badge text={u.role?.role_name} variant={ROLE_COLORS[u.role?.role_name] || 'gray'} /></td>
                  <td><StatusBadge status={u.status} /></td>
                  <td className="text-gray-500">{fmtDate(u.last_login)}</td>
                  <td>
                    <button onClick={() => toggleStatus(u.id)}
                      className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${u.status === 'active' ? 'border-red-200 text-red-600 hover:bg-red-50' : 'border-green-200 text-green-600 hover:bg-green-50'}`}>
                      {u.status === 'active' ? 'Nonaktifkan' : 'Aktifkan'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'roles' && (
        <div>
          <p className="text-sm text-gray-500 mb-4">Matriks hak akses per role dalam sistem.</p>
          <div className="card overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 border-b border-gray-100">Modul</th>
                  {ROLES.map(r => (
                    <th key={r} className="px-4 py-3 text-center text-xs font-medium text-gray-500 border-b border-gray-100">
                      <Badge text={r} variant={ROLE_COLORS[r] || 'gray'} />
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.keys(PERMISSIONS_MATRIX.Admin).map(mod => (
                  <tr key={mod} className="border-b border-gray-50 hover:bg-gray-50/50">
                    <td className="px-4 py-3 font-medium text-gray-700">{mod}</td>
                    {ROLES.map(role => {
                      const perms = PERMISSIONS_MATRIX[role]?.[mod] || []
                      return (
                        <td key={role} className="px-4 py-3 text-center">
                          {perms.length > 0 ? (
                            <div className="flex flex-wrap gap-1 justify-center">
                              {perms.map(p => <span key={p} className="text-xs px-1.5 py-0.5 bg-primary-light text-primary rounded">{p}</span>)}
                            </div>
                          ) : (
                            <span className="text-gray-300">—</span>
                          )}
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Tambah User */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Tambah Pengguna Baru"
        footer={<><Button label="Batal" onClick={() => setShowModal(false)} /><Button label="Simpan" variant="primary" onClick={handleAdd} /></>}>
        <FormField label="Nama Lengkap" required>
          <input className="input-field" value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} placeholder="Nama pengguna" />
        </FormField>
        <FormField label="Email" required>
          <input type="email" className="input-field" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="email@domain.id" />
        </FormField>
        <FormField label="Password" required hint="Minimal 8 karakter">
          <input type="password" className="input-field" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="••••••••" />
        </FormField>
        <FormField label="Role">
          <select className="select-field" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}>
            {ROLES.map(r => <option key={r}>{r}</option>)}
          </select>
        </FormField>
      </Modal>
    </DashboardLayout>
  )
}
