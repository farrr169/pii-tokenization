import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { Shield, CheckCircle, XCircle, Layers, Clock, TrendingUp } from 'lucide-react'
import { DashboardLayout } from '../../components/layout/DashboardLayout'
import { StatCard, StatusBadge } from '../../components/ui'
import { tokenizationApi, auditApi, jobsApi } from '../../api'

const WEEK_DATA = [
  { day: 'Sen', count: 245 }, { day: 'Sel', count: 389 }, { day: 'Rab', count: 412 },
  { day: 'Kam', count: 298 }, { day: 'Jum', count: 521 }, { day: 'Sab', count: 187 },
  { day: 'Min', count: 334 },
]
const PIE_DATA = [
  { name: 'NIK', value: 42 }, { name: 'Rekening', value: 28 },
  { name: 'Kartu Kredit', value: 19 }, { name: 'Lainnya', value: 11 },
]
const PIE_COLORS = ['#185FA5', '#1D9E75', '#BA7517', '#5F5E5A']

const fmtNum = n => Number(n).toLocaleString('id-ID')
const fmtDate = d => new Date(d).toLocaleString('id-ID', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })

export default function Dashboard() {
  const { data: stats } = useQuery({
    queryKey: ['stats'],
    queryFn: () => tokenizationApi.stats().then(r => r.data.data),
    placeholderData: { total_tokenizations: 14872, success_count: 14651, failed_count: 221, success_rate: 98.5, total_jobs: 47, avg_processing_time_ms: 12 }
  })

  const { data: auditData } = useQuery({
    queryKey: ['audit-recent'],
    queryFn: () => auditApi.list({ limit: 5 }).then(r => r.data.data),
    placeholderData: [
      { id: '1', user: { full_name: 'Admin System' }, module_name: 'tokenization', activity: 'tokenize', ip_address: '192.168.1.10', created_at: new Date().toISOString() },
      { id: '2', user: { full_name: 'Operator 1' }, module_name: 'auth', activity: 'login', ip_address: '192.168.1.25', created_at: new Date().toISOString() },
    ]
  })

  const { data: jobsData } = useQuery({
    queryKey: ['jobs-recent'],
    queryFn: () => jobsApi.list({ limit: 3 }).then(r => r.data.data),
    placeholderData: [
      { id: '1', job_name: 'Batch NIK Q4-2024', total_data: 500, success_count: 498, failed_count: 2, status: 'completed', created_at: new Date().toISOString() },
    ]
  })

  return (
    <DashboardLayout title="Dashboard">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        <StatCard label="Total Tokenisasi" value={fmtNum(stats?.total_tokenizations)} sub="Semua waktu" icon={Shield} color="#185FA5" />
        <StatCard label="Berhasil" value={fmtNum(stats?.success_count)} sub={`Rate: ${stats?.success_rate}%`} icon={CheckCircle} color="#1D9E75" />
        <StatCard label="Gagal" value={fmtNum(stats?.failed_count)} sub="Perlu perhatian" icon={XCircle} color="#A32D2D" />
        <StatCard label="Total Jobs" value={stats?.total_jobs} sub="Batch proses" icon={Layers} color="#BA7517" />
        <StatCard label="Avg Waktu" value={`${stats?.avg_processing_time_ms}ms`} sub="Per tokenisasi" icon={Clock} color="#993556" />
        <StatCard label="Success Rate" value={`${stats?.success_rate}%`} sub="Tingkat keberhasilan" icon={TrendingUp} color="#185FA5" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* Bar chart */}
        <div className="card col-span-2">
          <h3 className="text-sm font-medium text-gray-600 mb-4">Aktivitas Tokenisasi 7 Hari</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={WEEK_DATA} barSize={28}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9ca3af' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <Tooltip formatter={(v) => [fmtNum(v), 'Tokenisasi']} contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)', fontSize: 12 }} />
              <Bar dataKey="count" fill="#185FA5" radius={[4, 4, 0, 0]} opacity={0.85} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="card">
          <h3 className="text-sm font-medium text-gray-600 mb-4">Distribusi PII Type</h3>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie data={PIE_DATA} cx="50%" cy="50%" innerRadius={35} outerRadius={60} dataKey="value" paddingAngle={2}>
                {PIE_DATA.map((_, i) => <Cell key={i} fill={PIE_COLORS[i]} />)}
              </Pie>
              <Tooltip formatter={(v) => [`${v}%`, '']} contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)', fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {PIE_DATA.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: PIE_COLORS[i] }} />
                  <span className="text-gray-600">{d.name}</span>
                </div>
                <span className="font-medium">{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent audit */}
        <div className="card">
          <h3 className="text-sm font-medium text-gray-600 mb-3">Aktivitas Terbaru</h3>
          <div className="space-y-2">
            {(auditData || []).map(log => (
              <div key={log.id} className="flex items-center gap-3 text-sm">
                <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium text-gray-500 flex-shrink-0">
                  {log.user?.full_name?.charAt(0) || '?'}
                </div>
                <div className="flex-1 overflow-hidden">
                  <span className="font-medium text-gray-800">{log.user?.full_name}</span>
                  <span className="text-gray-400 mx-1">·</span>
                  <span className="text-gray-500">{log.activity} {log.module_name}</span>
                </div>
                <span className="text-xs text-gray-400 flex-shrink-0">{fmtDate(log.created_at)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent jobs */}
        <div className="card">
          <h3 className="text-sm font-medium text-gray-600 mb-3">Batch Jobs Terbaru</h3>
          <div className="space-y-3">
            {(jobsData || []).map(job => {
              const rate = job.total_data > 0 ? Math.round((job.success_count / job.total_data) * 100) : 0
              return (
                <div key={job.id}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700 truncate flex-1 mr-3">{job.job_name}</span>
                    <StatusBadge status={job.status} />
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    <span>{fmtNum(job.total_data)} data</span>
                    <span>·</span>
                    <span className="text-green-600">{fmtNum(job.success_count)} berhasil</span>
                    {job.failed_count > 0 && <><span>·</span><span className="text-red-500">{job.failed_count} gagal</span></>}
                  </div>
                  {job.total_data > 0 && (
                    <div className="mt-1.5 h-1 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${rate}%` }} />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
